# WP Rocket | Custom Config File

Checks if site_url() and home_url() are different, and creates an extra configuration file if needed.
